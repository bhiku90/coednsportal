from flask import Flask, request, jsonify
import numpy as np
import pickle


def predict(theta1, theta2, X):
    m = len(X)
    num_labels = np.size(theta2, 1)
    p = np.zeros((len(X), 1))
    h1 = sigmoid(np.matmul(np.append(np.ones((m, 1)), X, axis=1), np.transpose(theta1)))
    h2 = sigmoid(np.matmul(np.append(np.ones((m, 1)), h1, axis=1), np.transpose(theta2)))
    return h2


def sigmoid(z):
    z1 = 1.0 + np.divide(1.0, np.exp(z))
    g = np.divide(1.0, z1)
    return g


app = Flask(__name__)

@app.after_request
def add_header(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    return response

@app.route('/safe_score', methods=['POST', 'GET'])
def safe_score():
    if request.method == 'POST':
        content = (request.get_json(force=True))
        gg = (content['email'])
        #print("received "+ str(gg))
        # print(gg)
        email = np.array(gg)
        features = np.array([email])
        theta = pickle.load(open('finalized_model.sav', 'rb'))
        theta1 = theta[0][0]
        theta2 = theta[1][0]
        features = np.array(features, np.int32)
        predicted = predict(theta1, theta2, features)
        print(predicted)
        result_ar = predicted[0]
        result = result_ar[0]
        #print(result)
        #print(round(1 - result))
        return jsonify({"email": str(round((1 - result) * 100))})


if __name__ == '__main__':
    app.run(debug=True)
    # app.run(host='0.0.0.0', port=80)
